package com.example.collectionwebtoon;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

//friday fragment
public class FragFriday extends Fragment {

    TextView fridayText;

    public FragFriday(){

    }

    @Override
    //fragment 생명주기
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_friday,container,false);

        String title = this.getArguments().getString("title");
        int where_to_go = this.getArguments().getInt("where_to_go");
        fridayText = view.findViewById(R.id.fridayText);
        if (title != null && where_to_go == 1) {
            fridayText.setText(title);
        }else{
            fridayText.setText("FridayText"+where_to_go);
        }

        return view;

    }
}
