package com.example.collectionwebtoon;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class FragThursday extends Fragment {

    TextView thursdayText;

    public FragThursday(){

    }

    @Override
    //fragment 생명주기
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_thursday,container,false);

        String title = this.getArguments().getString("title");
        int where_to_go = this.getArguments().getInt("where_to_go");
        thursdayText = view.findViewById(R.id.thursdayText);
        if (title != null && where_to_go == 1) {
            thursdayText.setText(title);
        }else{
            thursdayText.setText("thursdayText"+where_to_go);
        }

        return view;

    }
}
