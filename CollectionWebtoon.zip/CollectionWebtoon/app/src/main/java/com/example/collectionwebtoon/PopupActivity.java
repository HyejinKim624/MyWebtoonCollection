package com.example.collectionwebtoon;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class PopupActivity extends Activity {

    private EditText title_et;
    private Button btnAdd;
    private Spinner flatform, daySpinner;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        //start popup setting
        //타이틀 바 제거
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        //배경 블러 처리
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        layoutParams.dimAmount = 0.7f;
        getWindow().setAttributes(layoutParams);

        //레이아웃 설정
        setContentView(R.layout.activity_popup);

        //사이즈 조절
        //디스플레이 화면 사이즈 구하기
        Display dp = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        //화면비율 설정
        int width = (int)(dp.getWidth()*0.7);
        int height = (int)(dp.getHeight()*0.7);
        //현재 화면에 적용
        getWindow().getAttributes().width = width;
        getWindow().getAttributes().height = height;

        //액티비티 바깥화면 클릭해도 종료되지 않음
        this.setFinishOnTouchOutside(false);
        //end popup setting



        flatform = findViewById(R.id.flatformspinner);
        title_et = findViewById(R.id.text_webtoonTitle);
        btnAdd = findViewById(R.id.btn_add);
        daySpinner = findViewById(R.id.dayspinner);

        intent = new Intent(PopupActivity.this, MenuActivity.class);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                daySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String str = parent.getItemAtPosition(position).toString();
                        switch (str) {
                            //MenuActivity 에서 문자열을 받고 어느 프래그먼트에 추가시킬지 판단
                            case "월요일":
                                //월요일 부분에 추가
                                intent.putExtra("Frag", 1);
                                break;
                            case "화요일":
                                //화요일 부분에 추가
                                intent.putExtra("Frag", 2);
                                break;
                            case "수요일":
                                //수요일 부분에 추가
                                intent.putExtra("Frag", 3);
                                break;
                            case "목요일":
                                //목요일 부분에 추가
                                intent.putExtra("Frag", 4);
                                break;
                            case "금요일":
                                //금요일 부분에 추가
                                intent.putExtra("Frag", 5);
                                break;
                            case "토요일":
                                //토요일 부분에 추가
                                intent.putExtra("Frag", 6);
                                break;
                            case "일요일":
                                //일요일 부분에 추가
                                intent.putExtra("Frag", 7);
                                break;
                            default:
                                //기타 부분에 추가
                                intent.putExtra("Frag", 8);
                                break;
                        }
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                //입력 받은 웹툰 제목 인텐트로 넘긴다
                intent.putExtra("title", title_et.getText().toString());
                startActivity(intent);
                overridePendingTransition(R.anim.loadfadein,R.anim.loadfadeout);
            }
        });




    }
}