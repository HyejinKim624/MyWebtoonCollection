package com.example.collectionwebtoon;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

//saturday fragment
public class FragSaturday extends Fragment {

    TextView saturdayText;

    public FragSaturday(){

    }

    @Override
    //fragment 생명주기
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_saturday,container,false);

        String title = this.getArguments().getString("title");
        int where_to_go = this.getArguments().getInt("where_to_go");
        saturdayText = view.findViewById(R.id.saturdayText);
        if (title != null && where_to_go == 1) {
            saturdayText.setText(title);
        }else{
            saturdayText.setText("SaturdayText"+where_to_go);
        }

        return view;

    }
}
