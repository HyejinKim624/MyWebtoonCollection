package com.example.collectionwebtoon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity {

    private ImageButton attendBtn, btnMon, btnTue, btnWed, btnThu, btnFri, btnSat, btnSun, btnEtc, btnRec;
    private Intent intent;
    private int where_to_go;
    private String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        //Button
        attendBtn = findViewById(R.id.attendBtn);
        btnMon = findViewById(R.id.btn_mon);
        btnTue = findViewById(R.id.btn_tue);
        btnWed = findViewById(R.id.btn_wed);
        btnThu = findViewById(R.id.btn_thu);
        btnFri = findViewById(R.id.btn_fri);
        btnSat = findViewById(R.id.btn_sat);
        btnSun = findViewById(R.id.btn_sun);
        btnEtc = findViewById(R.id.btn_etc);
        btnRec = findViewById(R.id.btn_rec);


        //fragment 생성
        FragMonday fragMonday = new FragMonday();
        FragTuesday fragTuesday = new FragTuesday();
        FragWednesday fragWednesday = new FragWednesday();
        FragThursday fragThursday = new FragThursday();
        FragFriday fragFriday = new FragFriday();
        FragSaturday fragSaturday = new FragSaturday();
        FragSunday fragSunday = new FragSunday();
        FragEtc fragEtc = new FragEtc();
        FragRecord fragRecord = new FragRecord();


        //어느 프래그먼트로 이동할 건지와 웹툰 제목을 인텐트로 팝업 액티비티에서 건네 받음
        intent = getIntent();
        //%%해결해야 하는 부분: intent가 제대로 전달되지 않고 계속 디폴트 값이 나옴%%
        where_to_go = intent.getIntExtra("Frag", 2); //1:monday ~ 8:etc
        title = intent.getStringExtra("title");


        //###############test###############
        //프래그먼트 테스트용 나중에 지워야 됨
        Toast.makeText(getApplicationContext(), where_to_go+"", Toast.LENGTH_SHORT).show();
        //###############test###############


        attendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, PopupActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.loadfadein,R.anim.loadfadeout);
            }
        });


        //bundle로 프래그먼트에 데이터 전달
        Bundle bundle = new Bundle();
        btnMon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragMonday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragMonday);
                transaction.commit();
            }
        });

        btnTue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragTuesday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragTuesday);
                transaction.commit();
            }
        });

        btnWed.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragWednesday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragWednesday);
                transaction.commit();
            }
        });

        btnThu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragThursday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragThursday);
                transaction.commit();
            }
        });

        btnFri.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragFriday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragFriday);
                transaction.commit();
            }
        });

        btnSat.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragSaturday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragSaturday);
                transaction.commit();
            }
        });

        btnSun.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragSunday.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragSunday);
                transaction.commit();
            }
        });

        btnEtc.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                bundle.putString("title", title);
                bundle.putInt("where_to_go", where_to_go);
                fragEtc.setArguments(bundle);
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragEtc);
                transaction.commit();
            }
        });

        btnRec.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, fragRecord);
                transaction.commit();
            }
        });

    }
}