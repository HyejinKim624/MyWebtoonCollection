package com.example.collectionwebtoon;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;



//tuesday fragment
public class FragTuesday extends Fragment {

    TextView tuesdayText;

    public FragTuesday(){

    }

   @Override
    //fragment 생명주기
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_tuesday,container,false);

       String title = this.getArguments().getString("title");
       int where_to_go = this.getArguments().getInt("where_to_go");
       tuesdayText = view.findViewById(R.id.tuesdayText);
       if (title != null && where_to_go == 2) {
           tuesdayText.setText(title);
       }else{
           tuesdayText.setText("TuesdayText"+where_to_go);
       }

        return view;

    }


}
