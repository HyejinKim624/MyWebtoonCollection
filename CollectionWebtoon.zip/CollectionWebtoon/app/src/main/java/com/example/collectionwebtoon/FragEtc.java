package com.example.collectionwebtoon;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;


//기타 fragment
public class FragEtc extends Fragment {

    TextView etcText;

    @Override
    //fragment 생명주기
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_etc,container,false);

        String title = this.getArguments().getString("title");
        int where_to_go = this.getArguments().getInt("where_to_go");
        etcText = view.findViewById(R.id.etcText);
        if (title != null && where_to_go == 1) {
            etcText.setText(title);
        }else{
            etcText.setText("EtcText"+where_to_go);
        }

        return view;

    }
}
